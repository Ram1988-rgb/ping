<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Investment Detail</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard')?>">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/investment')?>">Investment</a></li>
              <li class="breadcrumb-item active">Investment Detail</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

   <!-- Main content -->
   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">              
              <!-- /.card-header -->
              <?php echo load_alert();?>
              <!-- form start -->
              <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          
          <!-- /.card-header -->
          <div class="card-body">
            <h4 class="sub-heading">User & Plan Detail</h4>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label>Name: </label>
                  <?php echo $record->name;?>
                </div>
                <!-- /.form-group -->
                <div class="form-group">
                  <label>Email: </label>
                  <?php echo $record->email;?>
                </div>
                <div class="form-group">
                  <label>Phone: </label>
                  <?php echo $record->phone;?>
                </div>
                
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <label>Plane: </label>
                  <?php echo JSON_DECODE($record->plan_data)->name;?>
                </div>
                <!-- /.form-group -->
                <div class="form-group">
                  <label>Payment Type: </label>
                  <?php echo JSON_DECODE($record->payment_type_data)->label;?>
                </div>
                <div class="form-group">
                  <label>Payment Duration :</label>
                  <?php echo JSON_DECODE($record->payment_deuration_data)->label;?>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.card-body -->
          <div class="card-body">
          <h4 class="sub-heading">Investment Detail</h4>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label>Start Date: </label>
                  <?php echo $record->start_date;?>
                </div>
                <!-- /.form-group -->
                <div class="form-group">
                  <label>Amount: </label>
                  <?php echo CURRENCY.$record->amount;?>
                </div>
                <div class="form-group">
                  <label>Installment Amount: </label>
                  <?php echo CURRENCY.$record->install_amount;?>
                </div>
                
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <label>End Date: </label>
                  <?php echo $record->end_date;?>
                </div>
                <!-- /.form-group -->
                <div class="form-group">
                  <label>Installment Count: </label>
                  <?php echo $record->installment_count;?>
                </div>
                <div class="form-group">
                  <label>Payment Duration :</label>
                  <?php echo $record->end_date;?>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          
        </div>
        <!-- /.card -->
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->