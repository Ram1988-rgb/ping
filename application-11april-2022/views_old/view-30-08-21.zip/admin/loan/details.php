<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Loan Details</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/loan')?>">Loan</a></li>
              <li class="breadcrumb-item active">Loan Details</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

   <!-- Main content -->
   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">              
              <!-- /.card-header -->
              <?php echo load_alert();?>
              <!-- form start -->
              
                <div class="card-body">	
                  <div class="form-group">
                    <label for="name">User Name</label> ::
                    <label for="name"><?php echo $details->name ? $details->name : 0 ;?></label>
                  </div> 
                  <div class="form-group">
                    <label for="name">Email</label> ::
                    <label for="name"><?php echo $details->email ? $details->email : 0 ;?></label>
                  </div> 		
                  <div class="form-group">
                    <label for="name">Phone</label> ::
                    <label for="name"><?php echo $details->phone ? $details->phone : 0 ;?></label>
                  </div> 	
				
                  <div class="form-group">
                    <label for="name">Loan Amount</label> ::
                    <label for="name"><?php echo $details->amount ? $details->amount : 0 ;?></label>
                  </div>  
                  
                   <div class="form-group">
                    <label for="name">Payment Type</label> ::
                    <label for="name"><?php echo JSON_DECODE($details->payment_type_data)->label; ?></label>
                  </div>
                  
                   <div class="form-group">
                    <label for="name">Loan Duration</label> ::
                    <label for="name"><?php echo JSON_DECODE($details->payment_deuration_data)->label; ?></label>
                  </div> 
                  <div class="form-group">
                    <label for="name">No of installment</label> ::
                    <label for="name"><?php echo $details->installment_count ? $details->installment_count : 0 ;?></label>
                  </div>
                  <div class="form-group">
                    <label for="name">Installment Amount</label> ::
                    <label for="name"><?php echo $details->install_amount ? $details->install_amount : 0 ;?></label>
                  </div>
                  <div class="form-group">
                    <label for="name">Status</label> ::
                    <label for="name"><?php echo $details->status ? "ACTIVe" : "PENDING" ;?></label>
                  </div>
                  
                <div class="card-footer">
                  <a href="<?php echo base_url('admin/loan')?>"><button class="btn btn-primary">Back</button></a>
                </div>                             
                 
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
