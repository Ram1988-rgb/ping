<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0"><i class="fa fa-user"></i> <?php echo $this->lang->line('Profile');?></h1>
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard')?>"><?php echo $this->lang->line('Dashboard');?></a></li>
               <li class="breadcrumb-item active"><?php echo $this->lang->line('Profile');?></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-6">
            <div class="p-2 px-3 border rounded mb-2">
                <div class="row align-items-center">
                    <div class="col-2 col-lg-1">
                        <i class="fas fa-wallet fa-2x"></i>
                    </div>
                    <div class="col-10 col-lg-11">
                        <label for="name" class="mb-0"><?php echo $this->lang->line('current_balance');?>: </label>
                        <P class="m-0">HGT 85,625</P>
                    </div>
                </div>
            </div>
            <div class="p-2 px-3 border rounded mb-2">
                <div class="row align-items-center">
                    <div class="col-2 col-lg-1">
                        <i class="fas fa-wallet fa-2x"></i>
                    </div>
                    <div class="col-10 col-lg-11">
                        <label for="name" class="mb-0"><?php echo $this->lang->line('total_investment');?>: </label>
                        <P class="m-0">HGT 21,000</P>
                    </div>
                </div>
            </div>
            <div class="p-2 px-3 border rounded mb-2">
                <div class="row align-items-center">
                    <div class="col-2 col-lg-1">
                        <i class="fas fa-wallet fa-2x"></i>
                    </div>
                    <div class="col-10 col-lg-11">
                        <label for="name" class="mb-0"><?php echo $this->lang->line('total_saving');?>: </label>
                        <P class="m-0">HGT 21,000</P>
                    </div>
                </div>
            </div>
         </div>
         <div class="col-md-6">
            <div class="p-2 px-3 border rounded mb-2">
               <div class="row">
                   <div class="col-8">
                       <label for="name"><img src="<?php if($this->session->userdata('CUSTOMERIMAGE')) { echo SHOW_USER_IMAGE_THUMB.$this->session->userdata('CUSTOMERIMAGE');}else{echo SHOW_AVATAR_IMAGE;}?>"></label>
                   </div>
                   <div class="col-4 text-right">
                       <a href="<?php echo base_url('user/home/edit_profile')?>">
                        <button type="button" class="btn border rounded text-capitalize"><i class="far fa-edit"></i> <?php // echo $this->lang->line('Edit Profile');?></button>
                       </a>
                   </div>
               </div>
            </div>
            <div class="p-2 px-3 border rounded mb-2">
               <label for="name" class="text-capitalize">Name: <?php echo $this->session->userdata('CUSTOMERNAME')?> </label> <br/>
            
                
               <label for="name">Email: <?php echo $this->session->userdata('CUSTOMEREMAIL')?></label>   <br/>
            
                
               <label for="name">Phone: <?php echo $this->session->userdata('CUSTOMERPHONE')?></label>   <br/>
            </div>
            <!--<div class="p-2 px-3 border rounded mb-2"> -->
            <!--   <a href="<?php echo base_url('user/home/edit_profile')?>">-->
            <!--   <button type="button" class="btn border rounded text-capitalize"><i class="far fa-edit"></i> <?php echo $this->lang->line('Edit Profile');?></button>-->
            <!--   </a>-->
            <!--</div>-->
         </div>
      </div>
     
     
      <div class="container-fluid px-0">
         <!-- Small boxes (Stat box) -->
         <?php echo load_alert();?>
         
        <!--My Bank-->
        <a href="<?php echo base_url('/')?>user/home/bank">
            <div class="mini-card">
                <div>
                    <strong><i class="fas fa-university mini-card-icon"></i></strong> 
                    <span class="mini-card-divider">|</span> <?php echo $this->lang->line('my_bank');?>
                </div>
                <div>
                    <span class="mini-card-divider">|</span>
                    <div class="mini-card-verify">
                        <i class="far fa-check-circle mini-card-icon"></i> Verified
                    </div>
                </div>
            </div>
        </a>
         
        <!--Verify Contact Number-->
        <a href="<?php echo base_url('/')?>user/home/contact">
            <div class="mini-card">
                <div>
                    <?php if($userData->verify_phone){?>
                        <strong><i class="fas fa-phone mini-card-icon"></i></strong>
                    <?php }?>
                    <span>
                        <span class="mini-card-divider">|</span> <?php echo $this->lang->line('verify_contact_number');?>
                    </span>
                </div>
                <div>
                    <span class="mini-card-divider">|</span>
                    <div class="mini-card-verify">
                        <i class="far fa-check-circle mini-card-icon"></i> Verified
                    </div>
                </div>
            </div>
        </a>
         
        <!--Verify Email-->
        <a href="<?php echo base_url('/')?>user/home/verify_email">
            <div class="mini-card">
                <div>
                    <?php if($userData->verify_email){?>
                        <strong><i class="far fa-envelope mini-card-icon"></i></strong>
                    <?php }?>
                    <span>
                        <span class="mini-card-divider">|</span> <?php echo $this->lang->line('verify_email_address');?>
                    </span>
                </div>
                <div>
                    <span class="mini-card-divider">|</span>
                    <div class="mini-card-verify">
                        <i class="far fa-check-circle mini-card-icon"></i> Verified
                    </div>
                </div>
            </div>
        </a>
        
        <!--Verify NIF-->
        <a href="<?php echo base_url('/')?>user/home/nif">
            <div class="mini-card">
                <div>
                    <strong><i class="fas fa-certificate mini-card-icon"></i></strong>
                    <span>
                        <span class="mini-card-divider">|</span> <?php echo $this->lang->line('verify_nif');?>
                    </span>
                </div>
                <div>
                    <span class="mini-card-divider">|</span>
                    <div class="mini-card-verify">
                        <i class="far fa-check-circle mini-card-icon"></i> Verified
                    </div>
                </div>
            </div>
        </a>
        
        <!--Pending-->
        <a href="<?php echo base_url('/')?>user/home/">
            <div class="mini-card">
                <div>
                    <strong><i class="fas fa-info-circle mini-card-icon"></i></strong>
                    <span>
                        <span class="mini-card-divider">|</span> Pending
                    </span>
                </div>
                <div>
                    <span class="mini-card-divider">|</span>
                    <div class="mini-card-pending">
                        <i class="far fa-times-circle mini-card-icon"></i> Pending
                    </div>
                </div>
            </div>
        </a>
        
        <!--Verify_dermalog-->
        <a href="<?php echo base_url('/')?>user/home/verify_dermalog">
            <div class="mini-card">
                <div>
                    <strong><i class="fas fa-box mini-card-icon"></i></strong>
                    <span>
                        <span class="mini-card-divider">|</span> <?php echo $this->lang->line('verify_dermalog');?>
                    </span>
                </div>
                <div>
                    <span class="mini-card-divider">|</span> 
                    <div class="mini-card-verify">
                        <i class="far fa-check-circle mini-card-icon"></i> Verified
                    </div>
                </div>
            </div>
        </a>
        
        <!--Add 2FA-->
        <a href="<?php echo base_url('/')?>user/home/verify_dermalog">
            <div class="mini-card">
                <div>
                    <strong><i class="fas fa-folder-plus mini-card-icon"></i></strong>
                    <span>
                        <span class="mini-card-divider">|</span> Add 2FA
                    </span>
                </div>
                <div>
                    <span class="mini-card-divider">|</span> 
                    <div class="mini-card-verify">
                        <i class="far fa-check-circle mini-card-icon"></i> Verified
                    </div>
                </div>
            </div>
        </a>
        
        
        
        
            
            
            
         <!-- /.row -->
         <div class="card mb-2">
            <div class="card-body">
               
               <a href="<?php echo base_url('/')?>user/home/bank"><button type="button" class="btn btn-primary"><?php echo $this->lang->line('my_bank');?></button></a>
                           
               <a href="<?php echo base_url('/')?>user/home/contact"><button type="button" class="btn btn-primary"><?php if($userData->verify_phone){?><i class="fa fa-check" aria-hidden="true"></i><?php }?> <?php echo $this->lang->line('verify_contact_number');?></button></a>
                           
               <a href="<?php echo base_url('/')?>user/home/verify_email"><button type="button" class="btn btn-primary"><?php if($userData->verify_email){?><i class="fa fa-check" aria-hidden="true"></i><?php }?> <?php echo $this->lang->line('verify_email_address');?></button></a>
                           
               <a href="<?php echo base_url('/')?>user/home/nif">
                  <button type="button" class="btn btn-primary"><?php echo $this->lang->line('verify_nif');?></button>
              </a>
                              
                           
               <?php if(!$userData->verify_dermalog){?>
                  <a href="<?php echo base_url('/')?>user/home/verify_dermalog"><button type="button" class="btn btn-primary"><?php echo $this->lang->line('verify_dermalog');?></button></a>
                  <?php }else {
                     ?>
                        <span class="btn alert-danger">
                            <?php if($userData->verify_dermalog == 2){?><i class="fa fa-check" aria-hidden="true"></i><?php }?>
                            <?php if($userData->verify_dermalog == 1){?><i class="fa fa-times" aria-hidden="true"></i> Pending</i><?php }?>
                        </span>
                  <button type="button" class="btn btn-primary"><?php echo $this->lang->line('verify_dermalog');?></button>
                  <?php } ?>
                  
                <a href="<?php echo base_url('/')?>user/home/add_fa">
                   <button type="button" class="btn btn-primary"><?php echo $this->lang->line('add_2fa');?></button>
                </a>
               
               <!-- /.card -->
            </div>
         </div>
         <!-- Main row -->
         <!-- /.row (main row) -->
      </div>
      <!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->