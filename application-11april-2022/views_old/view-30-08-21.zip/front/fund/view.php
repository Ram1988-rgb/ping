<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><i class="fas fa-coins"></i> <?php echo $this->lang->line('Fund');?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard')?>"><?php echo $this->lang->line('Home');?></a></li>
              <li class="breadcrumb-item active"><?php echo $this->lang->line('Fund');?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
          
          <?php echo load_alert()?>
          
          
            <div class="row align-items-end">
                <div class="col-8">
                    <div class="bg-white">
                        <h4 class="theme_heading"><?php echo $this->lang->line('Total Avilable Fund');?></h4>
                        <p class="mb-0 text-success font-weight-bold"><?php if($total_fund){echo "HTG ". $total_fund->amount;}?></p>
                    </div>
                </div>
                <div class="col-4 text-right">
                    <a href="<?php echo base_url('/')?>user/fund/add"><button type="button" class="btn btn-primary"><?php echo $this->lang->line('Add Fund');?></button></a>
                </div>
            </div>
            
            <hr />
                    
            <table id="example2" class="table table-bordered table-hover">
              <thead>
              <tr>
                <th><?php echo $this->lang->line('Name');?></th>  
                <th><?php echo $this->lang->line('Amount');?></th>
                <th><?php echo $this->lang->line('Status');?></th>
              </tr>
              </thead>
              <tbody>
              <?php
              if($all_record ){
                foreach ($all_record as $record)
                {
                ?>
                <tr id="row-<?php echo $record->id?>">
                  <td><?php echo $record->name?></td>
                  <td><?php echo $record->amount?></td>  
                  <td><?php if($record->status){?>Active<?php }else{?>Pending<?php }?></td>                   
                </tr>
              <?php
                }
              }
              ?>
              
              </tbody>
             
            </table>

           
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
