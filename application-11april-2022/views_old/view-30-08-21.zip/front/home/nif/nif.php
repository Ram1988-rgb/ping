<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?php echo $this->lang->line("Verify")?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('user/home')?>"><?php echo $this->lang->line('Home');?></a></li>
              <li class="breadcrumb-item active"><?php echo $this->lang->line("Nif")?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

   <!-- Main content -->
   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">              
              <!-- /.card-header -->
              <?php echo load_alert();?>
              <!-- form start -->
              <form id="addnif" action="" enctype="multipart/form-data" method="POST">
              <div class="card-body">
                <div class="form-group">
                  <h3><?php echo $this->lang->line("What do we ask for your NIF")?></h3>
						      <label for="name"><?php echo $this->lang->line("To confirm your identity on Nusol you need to connect your nif.This does not give Nuvest any access to tour bank information or balances.This just enables Nuvest confirm your isentity(realname, phone number & date of birth) from your bank.")?></label>
						    </div> 
                <div class="form-group">
                  <label for="name"><?php echo $this->lang->line("Id Name")?></label>
                  <input type="text" name="name" class="form-control" id="name" placeholder="<?php echo $this->lang->line("Id Name")?>" data-validation="required">
                </div>    
					 
                <div class="form-group">
                  <label for="name"><?php echo $this->lang->line("NIF No.")?></label>
                  <input type="text" name="nif_number" class="form-control" id="nif_number" placeholder="<?php echo $this->lang->line("NIF No.")?>" data-validation="required">
                </div>
					 
                <div class="form-group">
                  <label for="name"><?php echo $this->lang->line("Add Nif Image")?></label>
                  <input type="file" name="nif_image" class="form-control" data-validation="required">
                </div>					                        
                 
              </div>
                <!-- /.card-body -->
              <div class="card-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line("Get Verified")?></button>
              </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
