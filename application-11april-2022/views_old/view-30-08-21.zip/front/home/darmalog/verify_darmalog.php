<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?php echo $this->lang->line("Verify")?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('user/home')?>"><?php echo $this->lang->line('Home');?></a></li>
              <li class="breadcrumb-item active"><?php echo $this->lang->line("Dermalog")?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

   <!-- Main content -->
   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">              
              <!-- /.card-header -->
              <?php echo load_alert();?>
              <!-- form start -->
              <form id="addnif" action="" enctype="multipart/form-data" method="POST">
              <div class="card-body">
                <div class="form-group">
                  <h3><?php echo $this->lang->line("Proof of identity")?></h3>
				    <label for="name"><?php echo $this->lang->line("In order to completed to your verification Please upload a copy of passport with a clear selfie photo to proof the document holder.")?></label>
				</div> 
                <div class="form-group">
                  <label for="name"><?php echo $this->lang->line("Upload Proof identity")?></label>
                  <input type="file" name="proof_image" class="form-control" id="proof_image" placeholder="<?php echo $this->lang->line("Upload Proof identity")?>" data-validation="required">
                    <p><?php echo $this->lang->line("We accept only Id card, Passport.")?></p>
                </div>    
					 
                <div class="form-group">
                  <h3><?php echo $this->lang->line("A selfie with your identity")?></h3>
				    <label for="name"><?php echo $this->lang->line("Please make sure that every details of the Id document is clearly visible.")?></label>
				</div> 
					 
                <div class="form-group">
                  <label for="name"><?php echo $this->lang->line("Take a selfie with identity")?></label>
                  <input type="file" name="selfie_image" id="selfie_image" class="form-control" data-validation="required">
                  <p><?php echo $this->lang->line("Please note Screenshots mobile phone bills and insurance are not accepted.")?></p>
                </div>					                        
                 
              </div>
                <!-- /.card-body -->
              <div class="card-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line("Get Verified")?></button>
              </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
