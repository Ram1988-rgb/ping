<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?php echo $this->lang->line('Bank Accounts');?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard')?>"><?php echo $this->lang->line('Home');?></a></li>
              <li class="breadcrumb-item active"><?php echo $this->lang->line('Bank Accounts');?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">              
              <!-- /.card-header -->
              <?php echo load_alert();?>
              <!-- form start -->
              <div class="card-body">
                  <h4><?php echo $this->lang->line("We've found ").count($all_record)?> <?php echo $this->lang->line(" bank accounts belongs to you.");?></h4>
                  <div class="form-group bank-head">
                  <?php
                  if($all_record ){
                    foreach ($all_record as $record)
                    {
                    ?>
                    <div class="row bank-div">
                      <div class="col-md-12">
                        <img src="<?php echo base_url('assets/Image/bank/bank.jpg')?>" width="50" height="50">
                        <label><?php echo $record->name?></label>
                        <p>******<?php echo substr($record->account_number, -4);?></p>
                      </div>
                    </div>
                    <?php 
                      }
                    }
                    ?>
                 </div>  
                 <div class="card-footer">
                 <a href="<?php echo base_url('user/home/add')?>">
                  <button type="button" class="btn btn-primary"><?php echo $this->lang->line("Add New")?></button>
                  </a>
                </div>
				                        
                 
                </div>
               
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    
    <!-- /.content -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
