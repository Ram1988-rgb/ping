<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dermalog</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard')?>">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/user')?>">User</a></li>
              <li class="breadcrumb-item active">Dermalog</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

   <!-- Main content -->
   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">              
              <!-- /.card-header -->
              <?php echo load_alert();?>
              <!-- form start -->
              <form id="adduser" action="" method="POST">
                <div class="card-body">
                <div class="form-group">
                <label for="name">Status</label>
                <?php if($userDetail->verify_dermalog<2){?>
                    <a href="http://[::1]/ping/admin/user/status_dermalog/<?php echo $userDetail->id?>">
								<button type="button" class="btn btn-block btn-primary btn-sm" style="width:100px;">Inactive</button>
							  </a>
                              <?php }else{?>
                              Active
                              <?php }?>
                </div>
                  <div class="form-group">
                    <label for="name">Name</label>
                    <?php echo $userDetail->name;?>
                    </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <?php echo $userDetail->email;?>
                 </div>
                  <div class="form-group">
                    <label for="phone">Phone</label>
                    <?php echo $userDetail->phone;?>
                 </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Proof Image</label>
                        <div>
                        <img src="<?php echo SHOW_DERMALOG_IMAGE_ORIGINAL.$dermalog->proof_image?>" width="300" height="100">
                        </div>
                    </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Selfie Image</label>
                    <div>>
                        <img src="<?php echo SHOW_DERMALOG_IMAGE_ORIGINAL.$dermalog->selfie_image?>" width="300" height="100">
                    </div>
                   </div>
                  
                <!-- /.card-body -->
           
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->