<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Cash Details</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/cash')?>">Cash</a></li>
              <li class="breadcrumb-item active">Cash Details</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

   <!-- Main content -->
   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">              
              <!-- /.card-header -->
              <?php echo load_alert();?>
              <!-- form start -->
              
                <div class="card-body">
				
				 <div class="form-group">
                    <label for="name">Name</label> ::
                    <label for="name"><?php echo $details->name ? $details->name : '' ;?></label>
                  </div>
                  <div class="form-group">
                    <label for="name">Total Deposite Amount</label> ::
                    <label for="name"><?php echo $details->amount ? $details->amount : 0 ;?></label>
                  </div>
                  <?php if($details->fundtype_id == 1){ ?>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Upload Receipt/Proof Image</label> ::
                    <img width="50" height="50" src="<?php echo base_url('assets/cash/test.PNG');?>" alt="tab1" class="img img-responsive"> 
                  </div>
                  <?php } ?>
                  <?php if($details->fundtype_id == 2){ ?>
					   <label for="exampleInputEmail1">Upload Check Image</label> 
					<div class="form-group" >
						<label for="exampleInputEmail1">Front Side</label> ::
						<img width="50" height="50" src="<?php echo base_url('assets/cash/test.PNG');?>" alt="tab1" class="img img-responsive"> 					
                    </div>
                    <div class="form-group">
						<label for="exampleInputEmail1">Back Side</label> ::
						<img width="50" height="50" src="<?php echo base_url('assets/cash/test.PNG');?>" alt="tab1" class="img img-responsive"> 
                    </div>
                  <?php } ?>
                  <?php if($details->fundtype_id == 3){ ?>
                  <div class="form-group" >
                    <label for="exampleInputEmail1">Special Code</label> ::
                    <spam for="exampleInputEmail1"><?php echo $details->agent_special_code ? $details->agent_special_code : '' ;?></spam>
                   </div>
                  <?php } ?>
                </div>
                
                <div class="card-footer">
                  <a href="<?php echo base_url('admin/cash')?>"><button class="btn btn-primary">Back</button></a>
                </div>   
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
