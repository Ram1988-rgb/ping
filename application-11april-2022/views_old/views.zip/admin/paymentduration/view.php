<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Payment Duration</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard')?>">Home</a></li>
              <li class="breadcrumb-item active">Payment Duration</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
          <div class="row">
            <div class="col-2"style="float:right;margin-bottom:20px">
              <a href="<?php echo base_url('admin/')?>paymentduration/add"><button type="button" class="btn btn-block btn-primary">Add Payment Duration</button></a>
            </div>
          </div>
          <?php echo load_alert()?>
          
            <div class="card">
              
              <!-- /.card-header -->
              <div class="card-body">
              
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Label</th>
                    <th>Month</th>  
                    <th>Desription</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  if($all_record ){
                    foreach ($all_record as $record)
                    {
                    ?>                    
                    <tr id="row-<?php echo $record->id?>">
                    <td><?php echo $record->label?></td>
                    <td><?php echo $record->month?></td>
                    <td><?php echo $record->description? $record->description: '--';?></td>
                      
                      <!--<td>
                        <a href="<?php echo site_url('admin/')?>paymentduration/edit/<?php echo $record->id?>">
                          <button type="button" class="btn btn-block btn-primary btn-sm edit-btn">Edit</button>
                        </a>
                      </td>-->
                    </tr>
                  <?
                    }
                  }
                  ?>
                  
                  </tbody>
                 
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

           
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->