<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0"><?php echo $this->lang->line('Home');?></h1>
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard')?>"><?php echo $this->lang->line('Dashboard');?></a></li>
               <li class="breadcrumb-item active"><?php echo $this->lang->line('Home');?></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-6">
            <label for="name"><?php echo $this->lang->line('current_balance');?>: </label>
            <P>HGT 85,625</P>
            <label for="name"><?php echo $this->lang->line('total_investment');?></label>        
            <p>HGT 21,000</p>
            <label for="name"><?php echo $this->lang->line('total_saving');?></label>
            <p>HGT 21,000</p>
         </div>
         <div class="col-md-6">
            <div class="row">
               <label for="name"><img src="<?php if($this->session->userdata('CUSTOMERIMAGE')) { echo SHOW_USER_IMAGE_THUMB.$this->session->userdata('CUSTOMERIMAGE');}else{echo SHOW_AVATAR_IMAGE;}?>"></label>
            </div>
            <div class="row">
               <label for="name"><?php echo $this->session->userdata('CUSTOMERNAME')?> </label>
            </div>
            <div class="row">
               <label for="name"><?php echo $this->session->userdata('CUSTOMEREMAIL')?></label>  
            </div>
            <div class="row">
               <label for="name"><?php echo $this->session->userdata('CUSTOMERPHONE')?></label>  
            </div>
            <div class="row"> 
               <a href="<?php echo base_url('user/home/edit_profile')?>">
               <button type="button" class="btn btn-sm btn-primary"><?php echo $this->lang->line('Edit Profile');?></button>
               </a>
            </div>
         </div>
      </div>
     
     
      <div class="container-fluid px-0">
         <!-- Small boxes (Stat box) -->
         <?php echo load_alert();?>
         <!-- /.row -->
         <div class="card mb-2">
            <div class="card-body">
               
               <a href="<?php echo base_url('/')?>user/home/bank"><button type="button" class="btn btn-primary"><?php echo $this->lang->line('my_bank');?></button></a>
                           
                           <a href="<?php echo base_url('/')?>user/home/contact"><button type="button" class="btn btn-primary"><?php if($userData->verify_phone){?><i class="fa fa-check" aria-hidden="true"></i><?php }?> <?php echo $this->lang->line('verify_contact_number');?></button></a>
                           
                           <a href="<?php echo base_url('/')?>user/home/verify_email"><button type="button" class="btn btn-primary"><?php if($userData->verify_email){?><i class="fa fa-check" aria-hidden="true"></i><?php }?> <?php echo $this->lang->line('verify_email_address');?></button></a>
                           
                           <a href="<?php echo base_url('/')?>user/home/nif">
                              <button type="button" class="btn btn-primary"><?php echo $this->lang->line('verify_nif');?></button>
                              </a>
                              
                           
                           <?php if(!$userData->verify_dermalog){?>
                              <a href="<?php echo base_url('/')?>user/home/verify_dermalog"><button type="button" class="btn btn-primary"><?php echo $this->lang->line('verify_dermalog');?></button></a>
                              <?php }else {
                                 ?>
                                    <span class="btn alert-danger">
                                        <?php if($userData->verify_dermalog == 2){?><i class="fa fa-check" aria-hidden="true"></i><?php }?>
                                        <?php if($userData->verify_dermalog == 1){?><i class="fa fa-times" aria-hidden="true"></i> Pending</i><?php }?>
                                    </span>
                              <button type="button" class="btn btn-primary"><?php echo $this->lang->line('verify_dermalog');?></button>
                              <?php } ?>
                              
                            <a href="<?php echo base_url('/')?>user/home/add_fa">
                               <button type="button" class="btn btn-primary"><?php echo $this->lang->line('add_2fa');?></button>
                            </a>
               
               <!-- /.card -->
            </div>
         </div>
         <!-- Main row -->
         <!-- /.row (main row) -->
      </div>
      <!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->