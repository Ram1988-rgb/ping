<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $planDetail->name?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('user/dashboard/index')?>"><?php echo $this->lang->line('Home')?></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url('user/investment/index')?>"><?php echo $this->lang->line('Investment')?></a></li>
              <li class="breadcrumb-item active"><?php echo $planDetail->name?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->

    <section class="content">
      <div class="container-fluid">
          
        <p><?php echo $planDetail->description?></p>
          
        <div class="card mb-2">
            <div class="card-header">
                <div class="my-balance">
                  <p class="theme_heading mb-0"><b><?php echo $this->lang->line('My Balance')?></b> : <?php echo CURRENCY;?> 85,625</p>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 col-sm-3">
                        <p class="theme_color font-bold"><?php echo $this->lang->line('Intrest')?></p>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <p class="theme_color font-bold"><?php echo $this->lang->line('Setting')?></p>
                    </div>
                    
                  </div> 
            </div>
        </div>
          
          
          
      <div class="card mb-2">
          <div class="card-header">
              <div class="row">
                <div class="col-md-12 heading-saving-option text-capitalize">
                  <h4 class="theme_heading mb-0"><?php echo $this->lang->line('Select a saving option')?></h4>
                </div>
              </div>          
          </div>
          
          <div class="card-body">
            <!-- jquery validation -->
              
          
              
              <!-- /.card-header -->
              <?php echo load_alert();?>
              
              <!-- form start -->
              <form id="addplan" action="" method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="name"><?php echo $this->lang->line('Payment Type')?></label>
                    <select name="payment_type" id="payment_type" class="form-control" required>
                      <option value="">Select</option>
                      <?php foreach($paymentType as $pType){?>
                        <option value="<?php echo $pType->id;?>"><?php echo $pType->label;?></option>
                      <?php }?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="name"><?php echo $this->lang->line('Your plan duration')?></label>
                    <select name="payment_duration" id="payment_duration" class="form-control" required>
                      <option value="">Select</option>
                      <?php foreach($paymentDuration as $pDuration){?>
                        <option value="<?php echo $pDuration->id;?>"><?php echo $pDuration->label;?></option>
                      <?php }?>
                    </select>
                  </div>
                 
                  <div class="form-group">
                    <label for="name"><?php echo $this->lang->line('Enter Amount for Saving')?></label>
                      <input type="text" name="amount" class="form-control" id="paymenttype" placeholder="<?php echo CURRENCY?>500" required><?php //echo $paymenttype->label?>
                  </div>   

                  <div class="form-group">
                    <label for="name"><?php echo $this->lang->line('Start Date')?></label>                      
                      <div class="input-group date" id="reservationdate" data-target-input="nearest">
                      <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker" >
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                        <input type="text" name="start_date" id="start_date" class="form-control datetimepicker-input" data-target="#reservationdate"  required>
                        
                    </div>
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Save & Continue</button>
                </div>
              </form>
            
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  
  <!-- /.content-wrapper -->
  <style>
      .investment-plans{
    border-style: solid;
    border-width: thin;
    background-color: wheat;
    padding:10px;
    margin:10px;
    margin-right:20px;

}

      </style>