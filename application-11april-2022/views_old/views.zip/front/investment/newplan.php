<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $this->lang->line('Investment')?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('user/dashboard/index')?>"><?php echo $this->lang->line('Home')?></a></li>
              <li class="breadcrumb-item active"><?php echo $this->lang->line('Investment')?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->

    <section class="content">
      <div class="container-fluid">
         <!-- /.card-body -->
         <?php echo load_alert();?>
         
         
        <div class="card mb-2">
            <div class="card-header">
                <div class="row">
                    <div class="col-8">
                        <h4 class="invest-current theme_heading"><?php echo $this->lang->line('Current Saving')?></h4>
                        <p class="invest-value theme_text"><?php echo CURRENCY?> <?php echo isset($total_investment->amount)?$total_investment->amount:0;?></p>
                    </div>
                    <div class="col-sm-4">
                        
                    </div>
                </div>
            </div>
        
         
         
            <div class="card-body">
           <div class="row">
          <div class="col-12 col-sm-12">
              
            <h4 class="investment-plan mb-3"><?php echo $this->lang->line('Investment Plan')?></h4>
              
              
            <div class="card  card-tabs">
              <div class="card-header bg-theme p-0 pt-1">
                <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" id="custom-tabs-one-home-tab" data-toggle="pill" href="#custom-tabs-one-home" role="tab" aria-controls="custom-tabs-one-home" aria-selected="true">New Plan</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="custom-tabs-one-profile-tab" data-toggle="pill" href="#custom-tabs-one-profile" role="tab" aria-controls="custom-tabs-one-profile" aria-selected="false">Summary</a>
                  </li>                  
                </ul>
              </div>
              <div class="card-body">
                <div class="tab-content" id="custom-tabs-one-tabContent">
                  <div class="tab-pane fade show active" id="custom-tabs-one-home" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
                    <?php foreach($all_investment_plan as $investmentPlan){ ?>
                        <div class="row" style="width:500px">
                        
                         <div class="col-sm-12 col-12 investment-plans" >
                         <a href="<?php echo base_url('user/investment/createplan/pid/'.$investmentPlan->id)?>">
                            <p><?php echo $investmentPlan->name?></p>
                            </a>
                         </div>
                         
                        </div>
                    <?php }?>
                  </div>
                  <div class="tab-pane fade" id="custom-tabs-one-profile" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                  <?php foreach($all_investment_plan as $investmentPlan){ 
                    $invs = $this->investment_model->get_total_investment($investmentPlan->id);
                    
                   ?>
                        <div class="row" style="width:500px">
                         <div class="col-sm-12 col-12 investment-plans">
                            <p><?php echo $investmentPlan->name?>: </p>
                            <?php echo isset($invs->amount)?$invs->amount:0;?>

                         </div>
                        </div>
                    <?php }?>
                  </div>
                  
                </div>
              </div>
              <!-- /.card -->
            </div>
          </div>
          
        </div>
        
          </div><!-- /.card-body -->
          
        </div> <!--card-body-->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <style>
      .investment-plans{
    border-style: solid;
    border-width: thin;
    background-color: wheat;
    padding:10px;
    margin:10px;
    margin-right:20px;

}

      </style>