			<div class="card-body">
                  <div class="form-group">
                    <label for="name">Select your loan request</label>
                    <label for="name">You can loan up to HTG 80,000</label>
                    <input type="text" name="amount" class="form-control" id="amount" placeholder="Enter Amount" required>
					        <label for="name">(Your Interest will be 3%)</label>
                 </div>
                
                 <div class="form-group">
                    <label for="name">Your Loan Duration</label>                 
                    <div>
                        <select name="loan_duration" id="loan_duration" class="form-control">
                            <option value="">Select</option>
                            <?php
                                if($loan_duration ){
                                    foreach ($loan_duration as $record){
                            ?>  
                                <option value="<?php echo $record->paymentduration_id;?>>"><?php echo $record->label?></option>
                            <?php 
                                    }
                                }
                            ?>
                        </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label for="name">Payment Duration will be?</label>                 
                  <div>
                  
                       <select name="payment_duration" id="payment_duration" class="form-control">
                            <option value="">Select</option>
                            <?php
                                if($payment_duration ){
                                    foreach ($payment_duration as $record){
                            ?>  
                                <option value="<?php echo $record->paymenttype_id;?>>"><?php echo $record->label?></option>
                            <?php 
                                    }
                                }
                            ?>
                        </select>
                   
                  </div>
                 </div>
             </div>
              