<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?php echo $this->lang->line('Dashboard');?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard')?>"><?php echo $this->lang->line('Home');?></a></li>
              <li class="breadcrumb-item active"><?php echo $this->lang->line('Dashboard');?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="card mb-2">
            <div class="card-body">
                <h4 class="theme_heading text-capitalize"><?php echo $this->session->userdata('CUSTOMERNAME')?></h4>
                <p>HTG <?php if($total_fund){ echo $total_fund->amount;}?></p>
            </div>
        </div>
        <div class="card mb-2">
            <div class="card-header">
                <h4 class="text-capitalize mb-0"><?php echo $this->lang->line('My Plan');?></h4>
            </div>
            <div class="card-body">
                 <div class="row">
                  <div class="col-lg-4 col-6">
                    <!-- small box -->
                    <div class="small-box small-box-primary">
                      <div class="inner">
                        <h3 class="text-capitalize">1500</h3>
        
                        <p><?php echo $this->lang->line('Total Cash');?></p>
                      </div>
                      <div class="icon">
                        <i class="ion ion-person-add"></i>
                      </div>
                    </div>
                  </div>
                  <!-- ./col -->
                  <div class="col-lg-4 col-6">
                    <!-- small box -->
                    <div class="small-box small-box-primary">
                      <div class="inner">
                        <h3 class="text-capitalize">1500</h3>
        
                        <p><?php echo $this->lang->line('Total Investments');?></p>
                      </div>
                      <div class="icon">
                        <i class="ion ion-person-add"></i>
                      </div>
                    </div>
                  </div>
                  <!-- ./col -->
                  <div class="col-lg-4 col-6">
                    <!-- small box -->
                    <div class="small-box small-box-primary">
                      <div class="inner">
                        <h3 class="text-capitalize"><?php if($total_loan){ echo $total_loan->amount;}?></h3>
        
                        <p><?php echo $this->lang->line('Total Loan');?></p>
                      </div>
                      <div class="icon">
                        <i class="ion ion-person-add"></i>
                      </div>
                    </div>
                  </div>
                 
                </div>
            </div>
        </div>
       
        <!-- /.row -->
        
        
        
       
        <div class="card mb-2">
            <div class="card-header">
                <h4 class="text-capitalize mb-0"><?php echo $this->lang->line('Choose Plan');?></h4>
            </div>
            <div class="card-body">
                <div class="row">
                    
                    <div class="col-lg-4 border-right">
                      <h4 class="theme_heading"><?php echo $this->lang->line('Cash');?></h4>
                      <p><?php echo $this->lang->line('Take a loan to cover personal expense and make purchase at low rates.');?></p>
                    </div>
                    
                    <div class="col-lg-4 border-right">
                        <h4 class="theme_heading"><?php echo $this->lang->line('Investment');?></h4>
                        <p><?php echo $this->lang->line('invest for heigher returns, make your money work for you.');?></p>
                    </div>
                    
                    <div class="col-lg-4">
                        <h4 class="theme_heading"><?php echo $this->lang->line('Loan');?></h4>
                        <p><?php echo $this->lang->line('Add cash quickly your account for favourable intrest rate.');?></p>
                    </div>
                    
                </div>
            </div>
        </div>

        
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
